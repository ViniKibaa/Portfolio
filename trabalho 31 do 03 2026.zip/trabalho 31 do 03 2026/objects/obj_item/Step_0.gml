if (place_meeting(x, y, obj_player)) {
    for (var i = 0; i < array_length(global.inventory); i++) {
        if (global.inventory[i] == -1) {
            global.inventory[i] = item_type;
            instance_destroy();
            break;
        }
    }
}