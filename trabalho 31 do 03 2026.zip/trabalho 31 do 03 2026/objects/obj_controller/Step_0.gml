if (keyboard_check_pressed(ord("I"))) {
    global.inv_open = !global.inv_open;
}