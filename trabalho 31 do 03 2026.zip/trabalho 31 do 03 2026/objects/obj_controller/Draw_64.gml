if (!global.inv_open) exit;

var slot_size = 40;

for (var i = 0; i < array_length(global.inventory); i++) {
    var xPos = 20 + i * (slot_size + 5);
    var yPos = 20;

    draw_rectangle(xPos, yPos, xPos + slot_size, yPos + slot_size, false);

    if (global.inventory[i] != -1) {
        draw_text(xPos + 10, yPos + 10, string(global.inventory[i]));
    }
}