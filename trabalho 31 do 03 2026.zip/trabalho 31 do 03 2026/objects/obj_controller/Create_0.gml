global.inventory = array_create(10, -1);
global.inv_open = false;