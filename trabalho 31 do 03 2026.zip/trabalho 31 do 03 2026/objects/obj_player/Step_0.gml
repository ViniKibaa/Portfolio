// Inputs
var _up    = keyboard_check(ord("W"));
var _left  = keyboard_check(ord("A"));
var _down  = keyboard_check(ord("S"));
var _right = keyboard_check(ord("D"));

var _spd = 4;
var _hspd = (_right - _left) * _spd;
var _vspd = (_down - _up) * _spd;

// Colisão Horizontal Simples
if (!place_meeting(x + _hspd, y, obj_wall)) {
    x += _hspd;
} else {
  
    if (!place_meeting(x + sign(_hspd), y, obj_wall)) {
        x += sign(_hspd);
    }
}

// Colisão Vertical Simples
if (!place_meeting(x, y + _vspd, obj_wall)) {
    y += _vspd;
} else {
    if (!place_meeting(x, y + sign(_vspd), obj_wall)) {
        y += sign(_vspd);
    }
}
