// Define para onde o jogador vai e em que posição ele aparece
room_goto(target_room);
other.x = target_x;
other.y = target_y;
